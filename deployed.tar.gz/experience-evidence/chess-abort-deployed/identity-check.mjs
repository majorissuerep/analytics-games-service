import {execFileSync} from 'node:child_process'
import assert from 'node:assert/strict'
const commit='5232dbc66a129522f6a6be4249b86aed4f48b39a',tree='e7035275741ca466b5b31cb8675ee8684cb7820a'
const identity=await (await fetch('https://analytics-games-service.vercel.app/api/build-identity',{cache:'no-store'})).json()
assert.equal(identity.commit,commit);assert.equal(identity.tree,tree)
assert.equal(execFileSync('git',['rev-parse',`${commit}^{tree}`],{encoding:'utf8'}).trim(),tree)
const ci=JSON.parse(execFileSync('gh',['run','view','43218818618','--json','status,conclusion,headSha,url'],{encoding:'utf8'}))
assert.equal(ci.conclusion,'success');assert.equal(ci.headSha,'e6b2b8a4227be213139fb24fb3c0ae3927f62681')
const statuses=JSON.parse(execFileSync('gh',['api',`repos/majorissuerep/analytics-games-service/commits/${commit}/status`],{encoding:'utf8'}))
const vercel=statuses.statuses.find(s=>s.context==='Vercel');assert.equal(vercel.state,'success')
const pr=JSON.parse(execFileSync('gh',['api','repos/majorissuerep/analytics-games-service/pulls/79'],{encoding:'utf8'}));assert.equal(pr.merged,true);assert.equal(pr.merge_commit_sha,commit)
console.log(JSON.stringify({checkedAt:new Date().toISOString(),identity,ci,vercel:{state:vercel.state,url:vercel.target_url},mergedPullRequest:pr.html_url,approvedTreeMatches:true},null,2))
