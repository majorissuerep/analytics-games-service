import { defineConfig } from '@playwright/test'
import original from '../../playwright.config'
export default defineConfig({ ...original, testDir: '../../tests/e2e', use: { ...original.use, proxy: { server: process.env.HTTPS_PROXY || process.env.HTTP_PROXY! } } })
