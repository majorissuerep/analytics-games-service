import ts from 'typescript'
import { readFileSync, writeFileSync, mkdtempSync, rmSync } from 'node:fs'
import { join } from 'node:path'
import { tmpdir } from 'node:os'
import { pathToFileURL } from 'node:url'
const directory = mkdtempSync(join(tmpdir(), 'elite-benchmark-'))
try {
  for (const name of ['model', 'solver']) {
    const source = readFileSync(`games/minefield/${name}.ts`, 'utf8').replace("from './model'", "from './model.mjs'")
    writeFileSync(join(directory, `${name}.mjs`), ts.transpileModule(source, { compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.ES2022 } }).outputText)
  }
  const {generateSolvableMinefield, solveMinefield} = await import(pathToFileURL(join(directory, 'solver.mjs')))
  const rows=[]
  for (const [name,w,h,m,layers] of [['beginner',9,9,10,1],['intermediate',16,16,40,1],['expert99',30,16,99,1],['extreme-elite',8,8,28,2]]) {
    const times=[], attempts=[]; let failures=0, badCertificates=0
    for (let sample=0;sample<30;sample++) {
      const openings=[0,Math.floor(w*h/2),w*h-1,Math.floor(w*h*layers/2),w*h*layers-1]
      const opening=openings[sample%openings.length], start=performance.now(); let tried=0
      try {
        const b=generateSolvableMinefield(w,h,m,opening,3000,n=>{tried=n},{layers,requireAdvanced:layers===2,maxMs:8000})
        times.push(performance.now()-start);attempts.push(tried)
        if(!solveMinefield(b,opening).solved)badCertificates++
        if(layers===2 && (solveMinefield(b,opening,{useSubset:false}).solved||solveMinefield(b,opening,{useEcho:false}).solved))badCertificates++
      } catch(error) { failures++; console.error(name,opening,error.message) }
    }
    times.sort((a,b)=>a-b)
    rows.push({name,samples:30,failures,badCertificates,p50Ms:times[Math.floor(times.length*.5)],p95Ms:times[Math.floor(times.length*.95)],worstMs:times.at(-1),maxAttempts:Math.max(...attempts)})
  }
  console.log(JSON.stringify({measuredAt:new Date().toISOString(),runtime:process.version,note:'Node on this QA host; browser/other device performance may differ. Five opening positions,30 random generations per mode.',rows},null,2))
  if(rows.some(r=>r.failures||r.badCertificates))process.exitCode=1
} finally {rmSync(directory,{recursive:true,force:true})}
