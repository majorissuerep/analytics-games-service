# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: chess-current-position.spec.ts >> only current predictions survive rapid free moves and late buffered responses
- Location: tests/e2e/chess-current-position.spec.ts:75:5

# Error details

```
Error: accepted move aborts prior work within the same action

expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false
```

# Page snapshot

```yaml
- generic [ref=e1]:
  - alert [ref=e2]
  - main [ref=e3]:
    - region "Games and platform tools" [ref=e5]:
      - button "Open Chess" [ref=e6]:
        - generic [ref=e8]: ♟️
        - generic [ref=e9]: Chess
      - button "Open Minefield" [ref=e10]:
        - generic [ref=e12]: 💣
        - generic [ref=e13]: Minefield
      - button "Open Space Cadet Pinball" [ref=e14]:
        - generic [ref=e16]: 🪐
        - generic [ref=e17]: Space Cadet Pinball
      - button "Open Paintbox" [ref=e18]:
        - generic [ref=e20]: 🎨
        - generic [ref=e21]: Paintbox
      - button "Mafia Online — Coming soon" [ref=e22]:
        - generic [ref=e24]: Mafia Online
        - generic [ref=e25]: Coming soon
      - button "🧩 Plugins" [ref=e26]:
        - generic [ref=e27]: 🧩
        - generic [ref=e28]: Plugins
      - button "? Build a game" [ref=e29]:
        - generic [ref=e30]: "?"
        - generic [ref=e31]: Build a game
    - article [ref=e33]:
      - generic [ref=e34]:
        - generic [ref=e35]:
          - generic [ref=e36]: 🎮
          - text: Chess
        - generic [ref=e37]:
          - button "Minimize" [ref=e38]
          - button "Maximize" [ref=e39]
          - button "Close" [ref=e40]
      - iframe [active] [ref=e43]:
        - generic [active] [ref=f1e1]:
          - main [ref=f1e3]:
            - generic [ref=f1e4]:
              - generic [ref=f1e5]:
                - generic [ref=f1e6]: ♞
                - strong [ref=f1e7]: Chess
                - generic [ref=f1e8]: Stockfish 18 · hints
              - generic [ref=f1e9]:
                - button "Unmute sounds" [ref=f1e10] [cursor=pointer]: Sound off
                - button "New game" [ref=f1e11] [cursor=pointer]
            - generic [ref=f1e12]:
              - generic "Chess board" [ref=f1e14]:
                - generic [ref=f1e15]:
                  - generic [ref=f1e17]:
                    - generic [ref=f1e18]: "8"
                    - button [ref=f1e20]:
                      - img [ref=f1e22]
                  - button [ref=f1e33]:
                    - img [ref=f1e35]
                  - button [ref=f1e45]:
                    - img [ref=f1e47]
                  - button [ref=f1e57]:
                    - img [ref=f1e59]
                  - button [ref=f1e78]:
                    - img [ref=f1e80]
                  - button [ref=f1e89]:
                    - img [ref=f1e91]
                  - button [ref=f1e101]:
                    - img [ref=f1e103]
                  - button [ref=f1e113]:
                    - img [ref=f1e115]
                  - generic [ref=f1e124]:
                    - generic [ref=f1e125]: "7"
                    - button [ref=f1e127]:
                      - img [ref=f1e129]
                  - button [ref=f1e134]:
                    - img [ref=f1e136]
                  - button [ref=f1e141]:
                    - img [ref=f1e143]
                  - button [ref=f1e148]:
                    - img [ref=f1e150]
                  - button [ref=f1e155]:
                    - img [ref=f1e157]
                  - button [ref=f1e162]:
                    - img [ref=f1e164]
                  - button [ref=f1e169]:
                    - img [ref=f1e171]
                  - button [ref=f1e176]:
                    - img [ref=f1e178]
                  - generic [ref=f1e182]: "6"
                  - generic [ref=f1e207]: "5"
                  - generic [ref=f1e232]: "4"
                  - button [disabled] [ref=f1e246]:
                    - img [ref=f1e248] [cursor=pointer]
                  - generic [ref=f1e261]: "3"
                  - generic [ref=f1e285]:
                    - generic [ref=f1e286]: "2"
                    - button [disabled] [ref=f1e288]:
                      - img [ref=f1e290] [cursor=pointer]
                  - button [disabled] [ref=f1e295]:
                    - img [ref=f1e297] [cursor=pointer]
                  - button [disabled] [ref=f1e302]:
                    - img [ref=f1e304] [cursor=pointer]
                  - button [disabled] [ref=f1e309]:
                    - img [ref=f1e311] [cursor=pointer]
                  - button [disabled] [ref=f1e319]:
                    - img [ref=f1e321] [cursor=pointer]
                  - button [disabled] [ref=f1e326]:
                    - img [ref=f1e328] [cursor=pointer]
                  - button [disabled] [ref=f1e333]:
                    - img [ref=f1e335] [cursor=pointer]
                  - generic [ref=f1e338]:
                    - generic:
                      - generic [ref=f1e339]: a
                      - generic [ref=f1e340]: "1"
                    - button [disabled] [ref=f1e342]:
                      - img [ref=f1e344] [cursor=pointer]
                  - generic [ref=f1e353]:
                    - generic [ref=f1e354]: b
                    - button [disabled] [ref=f1e356]:
                      - img [ref=f1e358] [cursor=pointer]
                  - generic [ref=f1e365]:
                    - generic [ref=f1e366]: c
                    - button [disabled] [ref=f1e368]:
                      - img [ref=f1e370] [cursor=pointer]
                  - generic [ref=f1e378]:
                    - generic [ref=f1e379]: d
                    - button [disabled] [ref=f1e381]:
                      - img [ref=f1e383] [cursor=pointer]
                  - generic [ref=f1e395]:
                    - generic [ref=f1e396]: e
                    - button [disabled] [ref=f1e398]:
                      - img [ref=f1e400] [cursor=pointer]
                  - generic [ref=f1e408]:
                    - generic [ref=f1e409]: f
                    - button [disabled] [ref=f1e411]:
                      - img [ref=f1e413] [cursor=pointer]
                  - generic [ref=f1e421]:
                    - generic [ref=f1e422]: g
                    - button [disabled] [ref=f1e424]:
                      - img [ref=f1e426] [cursor=pointer]
                  - generic [ref=f1e433]:
                    - generic [ref=f1e434]: h
                    - button [disabled] [ref=f1e436]:
                      - img [ref=f1e438] [cursor=pointer]
                  - img
                - status [ref=f1e446]
              - complementary [ref=f1e447]:
                - generic [ref=f1e450]:
                  - generic [ref=f1e451]: Both sides · free moves
                  - heading "Black to move" [level=2] [ref=f1e452]
                - navigation "Game details" [ref=f1e453]:
                  - button "Game" [pressed] [ref=f1e454] [cursor=pointer]
                  - button "Moves" [ref=f1e455] [cursor=pointer]
                - generic "Selected game details" [ref=f1e456]:
                  - generic [ref=f1e457]:
                    - generic [ref=f1e458]:
                      - generic [ref=f1e459]: ♘
                      - generic [ref=f1e460]:
                        - generic [ref=f1e461]: Stockfish 18
                        - generic [ref=f1e462]: Live hints · 20 lines · 600ms
                    - generic [ref=f1e464]:
                      - generic [ref=f1e465]:
                        - status [ref=f1e466]:
                          - strong [ref=f1e467]: "Stockfish 18: Connecting to the selected engine"
                        - timer "Elapsed time" [ref=f1e468]: 0s
                      - 'progressbar "Stockfish 18: Connecting to the selected engine" [ref=f1e469]'
                      - generic [ref=f1e471]:
                        - generic [ref=f1e472]: Working…
                        - button "Cancel" [ref=f1e473] [cursor=pointer]
                - generic [ref=f1e474]:
                  - button "↶ Undo" [ref=f1e475] [cursor=pointer]
                  - button "Leave game" [ref=f1e476] [cursor=pointer]
          - alert [ref=f1e477]
    - complementary "Pip desktop guide"
    - complementary "Desktop sticky note" [ref=e52]:
      - generic [ref=e53]:
        - generic [ref=e54]:
          - generic [ref=e55]: SCRATCHPAD
          - generic [ref=e56]: Quick note
        - button "Hide sticky note" [ref=e57] [cursor=pointer]: ×
      - textbox "Sticky note text" [ref=e58]:
        - /placeholder: A thought worth keeping…
        - text: Try a classic game — or write the next team-game idea here.
      - status [ref=e60]: Saved in this browser
    - generic [ref=e61]:
      - button "start" [ref=e62]:
        - generic [ref=e63]: ◆
        - strong [ref=e64]: start
      - button "🎮 Chess" [ref=e66]
      - generic [ref=e67]:
        - button "Talk to Pip" [ref=e69] [cursor=pointer]: 📎 Pip
        - img "4 games installed" [ref=e70]:
          - img [ref=e71]
          - generic [ref=e76]: "4"
        - generic [ref=e77]: 🔊
        - time [ref=e78]: 11:50:19 AM
```

# Test source

```ts
  1   | import { expect, test, type FrameLocator, type Page } from '@playwright/test'
  2   | import { Chess } from 'chess.js'
  3   | import { captureExperience, expectActionReady, overflowIssues } from './helpers/experience'
  4   | import { presentAnalysis } from '../../lib/engine/reckless-presentation'
  5   | 
  6   | type Pending = { fen: string; url: string; aborted: boolean; settled: boolean; previousAborted: boolean; resolve: (response: Response) => void }
  7   | declare global {
  8   |   interface Window { chessCancellationFixture?: { requests: Pending[] }; chessCancellationEvents?: string[] }
  9   | }
  10  | 
  11  | test.beforeEach(async ({ context }) => {
  12  |   await context.addInitScript(() => localStorage.setItem('analytics-games.analytics-consent.v1', 'denied'))
  13  | })
  14  | 
  15  | async function adversarialTransport(page: Page) {
  16  |   await page.addInitScript(() => {
  17  |     const original = window.fetch.bind(window)
  18  |     const state = window.chessCancellationFixture = { requests: [] as Pending[] }
  19  |     window.chessCancellationEvents = []
  20  |     window.addEventListener('message', event => { if (event.origin === location.origin && event.data?.kind === 'chess-fixture-abort') window.chessCancellationEvents?.push(event.data.url) })
  21  |     window.fetch = (input, init) => {
  22  |       const url = String(input)
  23  |       if (!url.endsWith('/api/chess/analyse') && !/\/api\/chess-models\/[^/]+\/move$/.test(url)) return original(input, init)
  24  |       return new Promise<Response>(resolve => {
  25  |         const item: Pending = { fen: JSON.parse(String(init?.body)).fen, url, aborted: Boolean(init?.signal?.aborted), settled: false, previousAborted: state.requests.filter(r => !r.settled).every(r => r.aborted), resolve }
  26  |         state.requests.push(item)
  27  |         init?.signal?.addEventListener('abort', () => { item.aborted = true; window.top?.postMessage({ kind: 'chess-fixture-abort', url }, location.origin) }, { once: true })
  28  |         // Intentionally ignores abort when completing fetch: tests obsolete buffered data,
  29  |         // independently of normal browser fetch's automatic AbortError rejection.
  30  |       })
  31  |     }
  32  |   })
  33  | }
  34  | async function openChess(page: Page) {
  35  |   await page.setViewportSize({ width: 1280, height: 900 })
  36  |   await page.goto('/')
  37  |   const welcome = page.locator('[data-window-id="system:welcome"]:visible')
  38  |   await expect(welcome).toBeVisible()
  39  |   await expectActionReady(welcome.getByRole('button', { name: 'Close', exact: true }))
  40  |   await welcome.getByRole('button', { name: 'Close', exact: true }).click()
  41  |   await page.locator('.desktop-icon[aria-label="Open Chess"]').dblclick()
  42  |   const frame = page.frameLocator('iframe[title="Chess"]:visible')
  43  |   await expect(frame.getByRole('navigation', { name: 'Game mode', exact: true })).toBeVisible()
  44  |   await expect(page.locator('.desktop-game-loader')).toHaveCount(0)
  45  |   return frame
  46  | }
  47  | async function startFree(frame: FrameLocator, engine = 'builtin-stockfish-18') {
  48  |   await frame.getByRole('button', { name: 'Free both sides', exact: true }).click()
  49  |   await frame.getByLabel('Analysis engine', { exact: true }).selectOption(engine)
  50  |   await frame.getByRole('button', { name: 'Play both sides · free moves', exact: true }).click()
  51  | }
  52  | async function requests(frame: FrameLocator) {
  53  |   return frame.locator('html').evaluate(() => window.chessCancellationFixture!.requests.map(({ fen, url, aborted, settled, previousAborted }) => ({ fen, url, aborted, settled, previousAborted })))
  54  | }
  55  | async function requestCount(frame: FrameLocator, count: number) { await expect.poll(async () => (await requests(frame)).length).toBe(count) }
  56  | async function move(frame: FrameLocator, from: string, to: string) {
  57  |   await frame.locator(`#analytics-chess-board-square-${from}`).click()
  58  |   await frame.locator(`#analytics-chess-board-square-${to}`).click()
  59  | }
  60  | async function deliver(frame: FrameLocator, index: number, label = 'Current result', error = false, stream = false) {
  61  |   const rows = await requests(frame), chess = new Chess(rows[index].fen)
  62  |   const legal = chess.moves({ verbose: true }).map(m => `${m.from}${m.to}${m.promotion ?? ''}`), uci = legal[0]
  63  |   const analysis = presentAnalysis(chess.fen(), chess.turn(), { bestMove: uci, lines: [{ multipv: 1, uci, scoreCp: 20, mateIn: null, bounded: false, depth: 12, pv: [uci] }] }, new Set(legal))
  64  |   analysis.balanceLabel = label
  65  |   await frame.locator('html').evaluate((_, { index, analysis, error, stream, uci }) => {
  66  |     const item = window.chessCancellationFixture!.requests[index]
  67  |     item.settled = true
  68  |     const body = error ? { error: 'Obsolete failure must never appear' } : item.url.endsWith('/move') ? { move: uci } : { analysis }
  69  |     const text = stream ? `event: progress\ndata: {"stage":"thinking","message":"OBSOLETE PROGRESS"}\n\nevent: result\ndata: ${JSON.stringify(body)}\n\n` : JSON.stringify(body)
  70  |     item.resolve(new Response(text, { status: error ? 503 : 200, headers: { 'content-type': stream ? 'text/event-stream' : 'application/json' } }))
  71  |   }, { index, analysis, error, stream, uci })
  72  |   return uci
  73  | }
  74  | 
  75  | test('only current predictions survive rapid free moves and late buffered responses', async ({ page }, info) => {
  76  |   await adversarialTransport(page)
  77  |   const frame = await openChess(page)
  78  |   await startFree(frame)
  79  |   await requestCount(frame, 1)
  80  |   await captureExperience(page, info, 'current-position', 'initial-current-loading')
  81  |   await frame.locator('#analytics-chess-board-square-e2').click()
  82  |   const abortedWithinAction = await frame.locator('#analytics-chess-board-square-e4').evaluate(element => {
  83  |     const before = window.chessCancellationFixture!.requests.filter(item => !item.aborted && !item.settled)
  84  |     ;(element as HTMLElement).click()
  85  |     return before.length > 0 && before.every(item => item.aborted)
  86  |   })
> 87  |   expect(abortedWithinAction, 'accepted move aborts prior work within the same action').toBe(true)
      |                                                                                         ^ Error: accepted move aborts prior work within the same action
  88  |   await requestCount(frame, 2)
  89  |   expect((await requests(frame))[0].aborted).toBe(true)
  90  |   await move(frame, 'e7', 'e5')
  91  |   await move(frame, 'g1', 'f3')
  92  |   await requestCount(frame, 4)
  93  |   const pending = await requests(frame)
  94  |   expect(pending.slice(0, 3).every(r => r.aborted)).toBe(true)
  95  |   expect(pending.every(r => r.previousAborted)).toBe(true)
  96  |   expect(pending[3].aborted).toBe(false)
  97  |   await deliver(frame, 0, 'OLD INITIAL', false, true)
  98  |   await deliver(frame, 1, 'OLD AFTER E4')
  99  |   await deliver(frame, 2, 'OLD ERROR', true)
  100 |   await expect(frame.locator('.chess-suggestion')).toHaveCount(0)
  101 |   await expect(frame.getByText(/OLD INITIAL|OLD AFTER E4|OBSOLETE PROGRESS|Obsolete failure/)).toHaveCount(0)
  102 |   await expect(frame.getByRole('heading', { name: 'Black to move' })).toBeVisible()
  103 |   await captureExperience(page, info, 'current-position', 'rapid-moves-obsolete-work-aborted')
  104 |   const uci = await deliver(frame, 3)
  105 |   await expect(frame.locator('.chess-suggestion-balance')).toContainText('Current result')
  106 |   await expect(frame.locator('.chess-suggestion')).toHaveAttribute('data-uci', uci)
  107 |   await frame.locator('.chess-suggestion').hover()
  108 |   await expect(frame.locator('.chess-hover-card')).toBeVisible()
  109 |   await captureExperience(page, info, 'current-position', 'only-current-hint-and-arrow')
  110 |   await frame.locator('.chess-suggestion').click()
  111 |   await requestCount(frame, 5)
  112 |   await expect(frame.locator('.chess-hover-card')).toHaveCount(0)
  113 |   await expect(frame.locator('.chess-suggestion')).toHaveCount(0)
  114 |   await expect(frame.getByRole('heading', { name: 'White to move' })).toBeVisible()
  115 |   await page.setViewportSize({ width: 390, height: 844 })
  116 |   await expectActionReady(frame.getByRole('button', { name: 'New game', exact: true }))
  117 |   await expectActionReady(frame.getByRole('button', { name: 'Leave game', exact: true }))
  118 |   await expect.poll(() => overflowIssues(frame.locator('.chess-app'), { allow: ['chess-utility-details'] })).toEqual([])
  119 |   await captureExperience(page, info, 'current-position', 'current-loading-narrow', 'clamped')
  120 | })
  121 | 
  122 | test('undo same FEN cancel retry reset and window close invalidate prediction generations', async ({ page }, info) => {
  123 |   await adversarialTransport(page)
  124 |   const frame = await openChess(page)
  125 |   await startFree(frame)
  126 |   await requestCount(frame, 1)
  127 |   await move(frame, 'e2', 'e4')
  128 |   await requestCount(frame, 2)
  129 |   await frame.getByRole('button', { name: /Undo/ }).click()
  130 |   await requestCount(frame, 3)
  131 |   let pending = await requests(frame)
  132 |   expect(pending[2].fen).toBe(pending[0].fen)
  133 |   expect(pending.slice(0, 2).every(r => r.aborted)).toBe(true)
  134 |   await deliver(frame, 0, 'OLD SAME FEN', false, true)
  135 |   await deliver(frame, 1, 'OLD OTHER FEN', true)
  136 |   await expect(frame.locator('.chess-suggestion')).toHaveCount(0)
  137 |   await expect(frame.getByText(/OLD SAME FEN|OBSOLETE PROGRESS|Obsolete failure/)).toHaveCount(0)
  138 |   await captureExperience(page, info, 'chess-lifecycle', 'same-fen-new-generation')
  139 |   await expectActionReady(frame.getByRole('button', { name: 'Cancel', exact: true }))
  140 |   await frame.getByRole('button', { name: 'Cancel', exact: true }).click()
  141 |   await expect(frame.getByText('Engine request stopped. Retry when ready.')).toBeVisible()
  142 |   await deliver(frame, 2, 'CANCELED CURRENT', false, true)
  143 |   await expect(frame.locator('.chess-suggestion')).toHaveCount(0)
  144 |   await expect(frame.getByRole('progressbar')).toHaveCount(0)
  145 |   await requestCount(frame, 3)
  146 |   await captureExperience(page, info, 'chess-lifecycle', 'explicit-cancel-awaits-retry')
  147 |   await frame.getByRole('button', { name: 'Retry', exact: true }).click()
  148 |   await requestCount(frame, 4)
  149 |   await frame.getByRole('button', { name: 'New game', exact: true }).click()
  150 |   pending = await requests(frame)
  151 |   expect(pending[3].aborted).toBe(true)
  152 |   await startFree(frame, 'builtin-stockfish-19')
  153 |   await requestCount(frame, 5)
  154 |   await deliver(frame, 3, 'OLD RESET RESULT')
  155 |   await expect(frame.locator('.chess-suggestion')).toHaveCount(0)
  156 |   await deliver(frame, 4, 'Fresh selected model')
  157 |   await expect(frame.locator('.chess-suggestion-balance')).toContainText('Fresh selected model')
  158 |   await captureExperience(page, info, 'chess-lifecycle', 'new-game-current-engine-result')
  159 |   await move(frame, 'e2', 'e4')
  160 |   await requestCount(frame, 6)
  161 |   const before = await page.evaluate(() => window.chessCancellationEvents!.length)
  162 |   await page.locator('[data-window-id="game:chess"]:visible').getByRole('button', { name: 'Close', exact: true }).click()
  163 |   await expect(page.locator('iframe[title="Chess"]')).toHaveCount(0)
  164 |   await expect.poll(() => page.evaluate(() => window.chessCancellationEvents!.length)).toBeGreaterThan(before)
  165 |   await captureExperience(page, info, 'chess-lifecycle', 'closing-window-aborts-current-work')
  166 | })
  167 | 
  168 | test('restored cached page starts a fresh generation for the same board', async ({ page }, info) => {
  169 |   await adversarialTransport(page)
  170 |   const frame = await openChess(page)
  171 |   await startFree(frame)
  172 |   await requestCount(frame, 1)
  173 |   await frame.locator('html').evaluate(() => window.dispatchEvent(new PageTransitionEvent('pagehide', { persisted: true })))
  174 |   expect((await requests(frame))[0].aborted).toBe(true)
  175 |   await frame.locator('html').evaluate(() => window.dispatchEvent(new PageTransitionEvent('pageshow', { persisted: true })))
  176 |   await requestCount(frame, 2)
  177 |   const pending = await requests(frame)
  178 |   expect(pending[1].fen).toBe(pending[0].fen)
  179 |   await deliver(frame, 0, 'OLD CACHED PAGE', false, true)
  180 |   await expect(frame.locator('.chess-suggestion')).toHaveCount(0)
  181 |   await captureExperience(page, info, 'chess-lifecycle', 'restored-page-fresh-loading')
  182 |   await deliver(frame, 1, 'Current restored board')
  183 |   await expect(frame.locator('.chess-suggestion-balance')).toContainText('Current restored board')
  184 |   await captureExperience(page, info, 'chess-lifecycle', 'restored-page-current-result')
  185 | })
  186 | 
  187 | test('automatic move and evaluation cannot complete into a reset board', async ({ page }, info) => {
```