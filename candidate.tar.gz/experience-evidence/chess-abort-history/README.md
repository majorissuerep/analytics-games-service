# Diagnostic history

These files are retained for audit and do not approve the final source.
The first local quality run exposed a gate fixture hardcoded to Minefield; it was made generic for the current app. The second full local quality run passed 235 unit tests and the build.

An initial browser assertion observed document click bubbling before Next/React handled the event. Both its first form and capture/bubble variant were invalid measurements of completion. The final test snapshots old requests, invokes the actual board click, and inspects those same requests immediately after the action returns. This corrected test fails on deployed baseline e816ad49 and passes the changed product. The corrected baseline video, trace, screenshots and log are retained here.

The first candidate report contains that diagnostic failed assertion and is deliberately unapproved. Its six other browser cases and independent manual observations are not reused as final approval: the final source received fresh browser and independent manual evidence in chess-abort-candidate2.

Candidate2 subsequently passed all97 requiredCI browser tests and235units, but was blocked by provider audit: Vercel disconnect cancellation is opt-in and actual asynchronous channel cleanup needs retained request lifetime. The source lacked both. Its frozen rejection report/review retain this major finding; candidate3 must repeat against the amended requirement.
